# EDApt2Exercises
Juypter Notebook and Data Set for EDA part 2 Exercises
